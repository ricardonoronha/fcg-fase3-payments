﻿namespace FIAP.MicroService.Payments.Domain.Dtos;

public class GetCheckoutResponse
{

}

