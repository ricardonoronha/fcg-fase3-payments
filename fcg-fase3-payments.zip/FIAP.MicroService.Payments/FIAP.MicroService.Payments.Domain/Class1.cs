﻿namespace FIAP.MicroService.Payments.Domain
{
    public class Class1
    {

    }
}
