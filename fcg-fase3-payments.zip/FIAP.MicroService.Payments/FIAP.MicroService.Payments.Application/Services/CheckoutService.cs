﻿using FIAP.MicroService.Payments.Domain.Dtos;
using FIAP.MicroService.Payments.Domain.Services;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIAP.MicroService.Payments.Application.Services
{
    public class CheckoutService(ILogger<CheckoutService> logger, IUserApiService userApiService, IGameApiService gameApiService) : ICheckoutService
    {
        public async Task<StartCheckoutResponse> StartCheckout(StartCheckoutRequest request, CancellationToken ct = default)
        {
            var getGameInfo = gameApiService.GetById(request.GameId);
            var getUserInfo = userApiService.GetById(request.UserId);

            //await Task.WhenAll(getUserInfo, getGameInfo);
            await getGameInfo;
            await getUserInfo;

            return new StartCheckoutResponse()
            {
                CheckoutId = Guid.NewGuid(),
                Game = getGameInfo.Result!,
                User = getUserInfo.Result!,
                PaymentMethods = new[] { "PIX", "Boleto" },
                Total = 100.00m
            };
        }


        public async Task<GetCheckoutResponse> GetCheckout(Guid checkoutId, CancellationToken ct = default)
        {
            await Task.CompletedTask;

            return new();
        }


        public async Task<FinishCheckoutResponse> FinishCheckout(Guid checkoutId, CancellationToken ct = default)
        {
            await Task.CompletedTask;

            return new()
            {
                CheckoutId = Guid.NewGuid(),
                GameId = Guid.NewGuid(),
                UserId = Guid.NewGuid()
            };
        }
    }
}
