﻿namespace FIAP.MicroService.Payments.Application
{
    public class Class1
    {

    }
}
